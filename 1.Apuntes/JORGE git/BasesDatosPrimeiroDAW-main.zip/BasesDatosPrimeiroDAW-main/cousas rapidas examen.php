<?php
$conexion=new mysqli('ip servidor','uisuario','','')