1. ¿Qué modelo de datos representa la información en forma de tablas?

`Modelo relacional.`
2. Los discos son...

`
Soportes de acceso directo a los datos.`
3. ¿Cuál de los siguientes no es un SGBD comercial?

`PostgreSQL.`
4. ¿Qué es un fichero?

`Un conjunto de información estructurada y relacionada que se representa como una secuencia de dígitos binarios.`
5. Queremos almacenar en una base de datos una entidad que represente a una Cita Médica de un centro de salud. Esta entidad tiene los siguientes atributos: médico, paciente, fecha, hora, síntomas, diagnóstico. ¿Cuál es la clave de la entidad?

`Médico, paciente, fecha, hora.`
6. ¿Cuál es una de las ventajas de las bases de datos distribuidas?

`Son más rápidas.`
7. ¿Cuál es el lenguaje más conocido para realizar consultas sobre bases de datos relacionales?

`SQL.`
8. ¿Qué tipo de usuario de una base de datos es el encargado de tomar las decisiones sobre la política de seguridad de la base de datos?

`El administrador.`
9. La fragmentación vertical se hace...

`Por columnas.`
10. ¿Qué es una base de datos?

`Un conjunto estructurado de datos que representa entidades y sus interrelaciones.`