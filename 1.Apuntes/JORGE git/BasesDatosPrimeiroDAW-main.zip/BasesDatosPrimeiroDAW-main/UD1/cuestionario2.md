1. ¿Cuál de las siguientes no es una ventaja de los Sistemas Gestores de Base de Datos?

**Aseguran la integridad de los datos**
2. Durante su diseño, una base de datos relacional pasa por un proceso al que se conoce como normalización de una base de datos. ¿Verdadero o Falso?

**Verdadeiro**
3. ¿Cuál de los siguientes sistemas gestores de base de datos libres está escrito en Java?

**Apache Derby**
4. El lenguaje que proporciona sentencias para realizar operaciones de DDL, DML y DCL es SQL. ¿Verdadero o Falso?

**Verdadeiro**
5. Al conjunto de valores que puede tomar un determinado atributo, se le denomina dominio. ¿Verdadero o Falso?

**Verdadeiro**
6. En una base de datos, los encargados de llevar a cabo la identificación de los datos, las relaciones entre ellos, sus restricciones, etc. serán:

**Los diseñadores.**
7. El lenguaje habitual para construir las consultas a bases de datos relacionales es DDL. ¿Verdadero o Falso?

**Falso**
8. ¿Cuál de los siguientes no es un tipo de base de datos documental?

**Directorios**
9. El nivel en el que se describe la estructura física de la base de datos, a través de un esquema interno encargado de detallar el sistema de almacenamiento de la base de datos y sus métodos de acceso, es:

**Nivel interno.**
10. Para nombrar abreviadamente un sistema de almacenamiento masivo en red, utilizamos las siglas

**NAS**
11. Un SAN corresponde a:

**Una red de área de almacenamiento.**
12. En una base de datos también se almacena una descripción de los datos, es lo que se denomina metadatos, se almacena en el catálogo y es lo que permite que exista independencia de datos lógica-física. ¿Verdadero o Falso?

**Verdadeiro**
13. El lugar donde se deposita la información sobre la totalidad de los datos que forman la base de datos y que contiene las características lógicas de las estructuras que almacenan los datos, su nombre, descripción, contenido y organización, se denomina:

**Diccionario de datos**
14. Para una base de datos, sólo existirá un único esquema externo, un único esquema conceptual y podrían existir varios esquemas internos definidos para uno o varios usuarios. ¿Verdadero o Falso?

**Falso**
15. En el modelo relacional de bases de datos, las tablas deben cumplir una serie de requisitos, ¿Cuál de los siguientes no es correcto?

**Todos los campos son del mismo tipo**
16. ¿Cuál de los siguientes sistemas gestores de base de datos no es comercial?

**Firebird**
17. Dentro de las funciones de los sistemas gestores de base de datos, la función de descripción se realiza mediante el lenguaje:

**DDL**
18. La forma visual del modelo jerárquico de bases de datos es de árbol, en la parte inferior están los padres y en la superior los hijos. ¿Verdadero o Falso?

**Falso**
