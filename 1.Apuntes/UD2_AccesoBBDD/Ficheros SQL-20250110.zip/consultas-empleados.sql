USE empleados;

#1
SELECT * FROM emp;

#2
SELECT * FROM depto;

#3
SELECT * FROM emp WHERE puesto LIKE 'CONTABLE';

#4
SELECT * FROM emp 
WHERE puesto LIKE 'CONTABLE'
ORDER BY nomemp;

#5
SELECT * FROM emp 
WHERE puesto LIKE 'CONTABLE'
ORDER BY nomemp DESC;

#6
SELECT nomemp AS 'NOMBRE', sal AS 'SALARIO' FROM emp;

#7
SELECT nomdep AS 'NOMBRE_DEPTO' FROM depto;

#8
SELECT nomdep AS 'NOMBRE_DEPTO' FROM depto ORDER BY localidad;

#9
SELECT nomemp, puesto, sal FROM emp ORDER BY sal DESC;

#10
SELECT nomemp, puesto, sal FROM emp ORDER BY puesto, sal DESC;

#11
SELECT sal, comision FROM emp WHERE numdep = 3;

#12
SELECT sal, comision FROM emp WHERE numdep = 3 ORDER BY comision;

#13
SELECT DISTINCT comision FROM emp;

#14
SELECT nomemp AS nombre, sal AS antiguo_salario, sal + 1000 AS nuevo_salario
FROM emp WHERE numdep = 3;

#15
SELECT nomemp, sal, comision FROM emp WHERE comision > (sal / 2);

#16
SELECT nomemp, sal, comision FROM emp WHERE comision <= (sal * 0.25);

#17
SELECT numemp, nomemp, sal, comision FROM emp WHERE numemp > 7500;
#18
SELECT numemp, nomemp, comision FROM emp 
WHERE comision IS NULL OR comision = 0
ORDER BY numemp;
#19
SELECT numemp, nomemp, sal AS salario, comision, sal + IFNULL(comision, 0) AS salario_total
FROM emp;
 
#20
SELECT numemp, nomemp FROM emp WHERE numdep = 1 AND nomemp NOT LIKE '%LA%';

#21
SELECT numdep, nomdep, localidad FROM depto 
WHERE nomdep NOT IN ('VENTAS', 'ADMINISTRACION')
ORDER BY localidad;

#22
SELECT nomemp, numdep, puesto, sal, feccont FROM emp
WHERE puesto = 'COMERCIAL' AND numdep != 1 AND sal > 800
ORDER BY feccont;

#23
SELECT nomemp, LENGTH(nomemp) AS longitud FROM emp WHERE LENGTH(nomemp) >= 5;
SELECT nomemp, LENGTH(nomemp) AS longitud FROM emp WHERE nomemp LIKE '_____%';
SELECT nomemp, LENGTH(nomemp) AS longitud FROM emp WHERE nomemp REGEXP '[A-z]{5,}';

#24
SELECT MAX(sal) AS salario_maximo, 
       SUM(comision) AS total_comisiones, 
       COUNT(numemp) AS total_empleados
FROM emp;

#25
SELECT d.* FROM emp e INNER JOIN depto d ON e.numdep=d.numdep
GROUP BY e.numdep
HAVING COUNT(e.numemp) > 3;

#26
SELECT * FROM emp ORDER BY sal DESC LIMIT 2;

#27
SELECT * FROM emp 
WHERE sal >= (SELECT AVG(sal) FROM emp);

#28
SELECT numemp, nomemp, numdep, sal FROM emp e1
WHERE sal = (SELECT MAX(sal) FROM emp e2 WHERE e2.numdep=e1.numdep);

#29
SELECT * FROM depto
WHERE numdep NOT IN (SELECT numdep FROM emp);

SELECT * FROM depto
WHERE numdep != ALL (SELECT numdep FROM emp);

SELECT * FROM depto d LEFT JOIN emp e ON d.numdep = e.numdep
WHERE e.numemp IS NULL;

SELECT d.* FROM depto d LEFT JOIN emp e ON d.numdep = e.numdep
GROUP BY d.numdep
HAVING COUNT(e.numemp) = 0;

#30
SELECT * FROM depto
WHERE numdep = (SELECT numdep FROM emp GROUP BY numdep ORDER BY SUM(sal) DESC LIMIT 1);

SELECT e.numdep, d.nomdep, SUM(e.sal) FROM emp e INNER JOIN depto d ON e.numdep = d.numdep
GROUP BY e.numdep
ORDER BY SUM(e.sal) DESC;

#31
SELECT * FROM emp WHERE numemp IN (SELECT numjefe FROM depto);

#32
SELECT * FROM emp
WHERE numdep IN (SELECT numdep FROM depto 
				WHERE localidad LIKE 'SANTIAGO' OR
                localidad LIKE 'VILAGARCIA');
                
SELECT * FROM emp
WHERE numdep IN (SELECT numdep FROM depto 
				WHERE localidad IN ('SANTIAGO', 'VILAGARCIA'));
                
SELECT e.numemp, e.nomemp, e.numdep, d.localidad
FROM emp e INNER JOIN depto d ON e.numdep=d.numdep
WHERE localidad = 'SANTIAGO' OR localidad = 'VILAGARCIA';

#33
SELECT * FROM emp e1
WHERE sal IN (SELECT MAX(sal) FROM emp e2
				GROUP BY numdep HAVING e1.numdep = e2.numdep);

SELECT * FROM emp e1
WHERE sal IN (SELECT MAX(sal) FROM emp e2 WHERE e1.numdep = e2.numdep
				GROUP BY numdep);



















































