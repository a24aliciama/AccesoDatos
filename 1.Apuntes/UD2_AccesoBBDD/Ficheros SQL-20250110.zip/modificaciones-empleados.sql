USE empleados;

#1
UPDATE emp
SET nomemp = 'JORGE'
WHERE numemp = 7499;

#2
UPDATE depto
SET localidad = 'MADRID'
WHERE nomdep LIKE 'OPERACIONES';

UPDATE depto,(SELECT numdep FROM depto
				WHERE nomdep LIKE 'OPERACIONES') AS dep
SET localidad = 'MADRID'
WHERE depto.numdep = dep.numdep;

#3
UPDATE emp
SET sal = 3000
WHERE numemp > 7800;

#4
DELETE FROM emp
WHERE nomemp LIKE 'FORD';

#5
UPDATE depto
SET numjefe = NULL
WHERE numjefe = 7934;

DELETE FROM emp
WHERE numemp = 7934;

#6
UPDATE emp
SET numdep = NULL
WHERE numdep = 3;

DELETE FROM depto
WHERE numdep = 3;




