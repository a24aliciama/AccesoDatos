package com.pepinho.ad.appcodigopostal

class CodigoPostal (val nome: String) {
}