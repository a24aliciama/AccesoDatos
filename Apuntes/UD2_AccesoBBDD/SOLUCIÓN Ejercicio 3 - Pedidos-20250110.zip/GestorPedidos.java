package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class GestorPedidos {
	private Connection conexion;
	
	private void abrirConexion() throws SQLException {
		conexion = DriverManager.getConnection("jdbc:mysql://localhost/tienda", "uadmin", "abc123.");
	}
	
	private void cerrarConexion() throws SQLException {
		conexion.close();
	}
	
	public Producto obtenerProducto(int id) {
		try {
			String sql = "SELECT * FROM producto WHERE id=?";
			abrirConexion();
			PreparedStatement consulta = conexion.prepareStatement(sql);
			consulta.setInt(1, id);
			ResultSet resultados = consulta.executeQuery();
			// Seleccionamos la información del producto
			resultados.next();
			String nombre = resultados.getString("nombre");
			String descripcion = resultados.getString("descripcion");
			double precio = resultados.getDouble("precio");
			cerrarConexion();
			// Devolvemos los datos del cliente
			return new Producto(id, nombre, descripcion, precio);
		} catch (SQLException e) {
			return null;
		}
	}
	
	public Cliente obtenerCliente(String dni) {
		try {
			String sql = "SELECT * FROM cliente WHERE dni=?";
			abrirConexion();
			PreparedStatement consulta = conexion.prepareStatement(sql);
			consulta.setString(1, dni);
			ResultSet resultados = consulta.executeQuery();
			// Seleccionamos la información del cliente
			resultados.next();
			String nombre = resultados.getString("nombre");
			cerrarConexion();
			// Devolvemos los datos del cliente
			return new Cliente(dni, nombre);
		} catch (SQLException e) {
			return null;
		}
	}
	
	public ArrayList<Pedido> obtenerPedidos(String dniCliente) {
		try {
			// Definimos las consultas que vamos a utilizar
			String sqlPedido = "SELECT * FROM pedido WHERE dniCliente=?";
			String sqlLineaPedido = "SELECT * FROM producto_pedido WHERE idPedido=?";
			String sqlProducto = "SELECT * FROM producto WHERE id=?";
			// Cargamos las consultas
			abrirConexion();
			PreparedStatement consultaPedido = conexion.prepareStatement(sqlPedido);
			PreparedStatement consultaLineaPedido = conexion.prepareStatement(sqlLineaPedido);
			PreparedStatement consultaProducto = conexion.prepareStatement(sqlProducto);
			// Obtenemos los datos del cliente
			Cliente cliente = obtenerCliente(dniCliente);
			// Ejecutamos la consulta que devuelve los pedidos del cliente
			consultaPedido.setString(1, dniCliente);
			ResultSet pedidosSQL = consultaPedido.executeQuery();
			// Creamos una lista que almacene los pedidos
			ArrayList<Pedido> pedidosCliente = new ArrayList<Pedido>();
			while (pedidosSQL.next()) {
				int idPedido = pedidosSQL.getInt("id");
				// Consultamos las lineas del pedido
				consultaLineaPedido.setInt(1, idPedido);
				ResultSet lineasPedidoSQL = consultaLineaPedido.executeQuery();
				// Creamos una lista que almacene las lineas del pedido
				ArrayList<LineaPedido> lineasPedido = new ArrayList<LineaPedido>();
				while (lineasPedidoSQL.next()) {
					// Obtenemos la información del producto
					int idProducto = lineasPedidoSQL.getInt("idProducto");
					consultaProducto.setInt(1, idProducto);
					ResultSet productoSQL = consultaProducto.executeQuery();
					productoSQL.next();
					int id = productoSQL.getInt("id");
					String nombre = productoSQL.getString("nombre");
					String descripcion = productoSQL.getString("descripcion");
					double precio = productoSQL.getDouble("precio");
					Producto producto = new Producto(id, nombre, descripcion, precio);
					// Añadimos la información del producto a la linea de pedido
					LineaPedido lineaPedido = new LineaPedido(idPedido, producto, lineasPedidoSQL.getInt("cantidad"));
					// Añadimos la linea de pedido al pedido
					lineasPedido.add(lineaPedido);
				}
				// Añadimos la información del pedido a la lista
				Pedido pedido = new Pedido(idPedido, pedidosSQL.getDate("fecha"), cliente, lineasPedido);
				pedidosCliente.add(pedido);
			}
			cerrarConexion();
			return pedidosCliente;
		} catch (SQLException e) {
			return null;
		}
	}
	
	public boolean añadirPedido(Pedido pedido) {
		try {
			// Definimos las sentencias que vamos a utilizar
			String sqlInsertarPedido = "INSERT INTO pedido(dniCliente,fecha) VALUES (?,?)";
			String sqlInsertarLineaPedido = "INSERT INTO producto_pedido VALUES (?,?,?)";
			// Cargamos las sentencias
			abrirConexion();
			PreparedStatement sentenciaInsertarPedido = conexion.prepareStatement(sqlInsertarPedido);
			PreparedStatement sentenciaInsertarLineaPedido = conexion.prepareStatement(sqlInsertarLineaPedido);
			// Insertamos el pedido
			sentenciaInsertarPedido.setString(1, pedido.getCliente().getDni());
			sentenciaInsertarPedido.setTimestamp(2, new Timestamp(pedido.getFecha().getTime()));
			sentenciaInsertarPedido.executeUpdate();
			// Insertamos las lineas del pedido
			for (LineaPedido lineaPedido: pedido.getLineasPedido()) {
				sentenciaInsertarLineaPedido.setInt(1, lineaPedido.getIdPedido());
				sentenciaInsertarLineaPedido.setInt(2, lineaPedido.getProducto().getId());
				sentenciaInsertarLineaPedido.setInt(3, lineaPedido.getCantidad());
				sentenciaInsertarLineaPedido.executeUpdate();
			}
			cerrarConexion();
			return true;
		} catch (SQLException e) {
			return false;
		}
	}
}
