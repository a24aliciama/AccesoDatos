package model;

import java.util.ArrayList;
import java.util.Date;

public class AppPedidos {
	
	public static void main(String[] args) {
		GestorPedidos gestorBD = new GestorPedidos();
		String dniCliente = "22222222B";
		// Obtenemos la información del cliente
		Cliente cliente = gestorBD.obtenerCliente(dniCliente);
		System.out.println(cliente);
		// Obtenemos los pedidos de ese cliente
		ArrayList<Pedido> pedidos = gestorBD.obtenerPedidos(dniCliente);
		for (Pedido pedido: pedidos) {
			System.out.println(pedido);
		}
		// Creamos un nuevo pedido para el cliente
		Producto producto = gestorBD.obtenerProducto(1);
		LineaPedido lineaPedido = new LineaPedido(3, producto, 5);
		ArrayList<LineaPedido> lineasPedido = new ArrayList<LineaPedido>();
		lineasPedido.add(lineaPedido);
		Date fechaActual = new Date(System.currentTimeMillis());
		Pedido nuevoPedido = new Pedido(3, fechaActual, cliente, lineasPedido);
		System.out.println(nuevoPedido);
		gestorBD.añadirPedido(nuevoPedido);
	}

}
