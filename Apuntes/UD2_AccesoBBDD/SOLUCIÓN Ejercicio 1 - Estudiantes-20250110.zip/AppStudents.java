package appStudents;

import java.util.ArrayList;
import java.util.Scanner;

public class AppStudents {
	private static Scanner sc = new Scanner(System.in);
	private static ManageStudents manager = new ManageStudents();
	
	
	private static void enrollStudent() {
		System.out.println("DNI del estudiante: ");
		String id = sc.next();
		System.out.println("Nombre del estudiante: ");
		String name = sc.next();
		System.out.println("Apellido del estudiante: ");
		String surname = sc.next();
		System.out.println("Edad del estudiante: ");
		int age = sc.nextInt();
		
		Student student = new Student(id, name, surname, age);
		boolean inserted = manager.addStudent(student);
		if (inserted) {
			System.out.println("USUARIO MATRICULADO CORRECTAMENTE.");
		} else {
			System.out.println("***PROBLEMA AL MATRICULAR USUARIO.");
		}
	}
	
	private static void dropStudent() {
		System.out.println("DNI del usuario: ");
		String id = sc.next();
		boolean deleted = manager.deleteStudent(id);
		if (deleted) {
			System.out.println("SE HA BORRADO CON ÉXITO AL ESTUDIANTE CON DNI " + id);
		} else {
			System.out.println("***PROBLEMA AL BORRAR ESTUDIANTE.");
		}
	}
	
	private static void updateStudent() {
		System.out.println("DNI del estudiante: ");
		String id = sc.next();
		System.out.println("Nombre del estudiante: ");
		String name = sc.next();
		System.out.println("Apellido del estudiante: ");
		String surname = sc.next();
		System.out.println("Edad del estudiante: ");
		int age = sc.nextInt();
		
		Student student = new Student(id, name, surname, age);
		boolean modified = manager.modifyStudent(student);
		if (modified) {
			System.out.println("USUARIO MODIFICADO CORRECTAMENTE.");
		} else {
			System.out.println("***PROBLEMA AL MODIFICAR USUARIO.");
		}
	}
	
	private static void showStudent() {
		System.out.println("DNI del usuario: ");
		String id = sc.next();
		Student student = manager.getStudent(id);
		if (student == null) {
			System.out.println("***PROBLEMA AL MOSTRAR USUARIO.");
		} else {
			System.out.println(student);
		}
	}
	
	private static void showAllStudents() {
		ArrayList<Student> students = manager.getStudentsList();
		for (int i = 0; i < students.size(); i++) {
			System.out.println("ESTUDIANTE #" + i);
			System.out.println(students.get(i));
		}
	}
	
	public static void main(String[] args) {
		while (true) {
			System.out.println("1.- MATRICULAR UN ESTUDIANTE");
			System.out.println("2.- DAR DE BAJA UN ESTUDIANTE");
			System.out.println("3.- ACTUALIZAR DATOS DE UN ESTUDIANTE");
			System.out.println("4.- VER DATOS DE UN ESTUDIANTE");
			System.out.println("5.- VER DATOS DE TODOS LOS ESTUDIANTES");
			System.out.println("6.- SALIR");
			System.out.println("Elige una de las siguientes opciones:");
			
			int opcion = Integer.parseInt(sc.next());
			
			switch (opcion) {
				case 1:
					enrollStudent();
					break;
				case 2:
					dropStudent();
					break;
				case 3:
					updateStudent();
					break;
				case 4:
					showStudent();
					break;
				case 5:
					showAllStudents();
					break;
				case 6:
					return;
			}
		}
	}
}
