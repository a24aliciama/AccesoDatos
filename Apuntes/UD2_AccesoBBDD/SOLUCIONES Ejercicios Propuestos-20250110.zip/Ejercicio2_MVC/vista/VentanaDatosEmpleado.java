package vista;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;

public class VentanaDatosEmpleado extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textNumEmp;
	private JTextPane textNombre;
	private JTextPane textPuesto;
	private JTextPane textSueldo;
	private JTextPane textComision;
	private JButton btnMostrar;
	private Controlador controlador;

	public VentanaDatosEmpleado(Controlador controlador) {
		this.controlador = controlador;
		
		setTitle("App empleado");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 579, 366);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblDatos = new JLabel("DATOS EMPLEADO");
		lblDatos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDatos.setBounds(200, 36, 174, 22);
		contentPane.add(lblDatos);

		JLabel lblNumEmp = new JLabel("Número de empleado:");
		lblNumEmp.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNumEmp.setBounds(44, 88, 188, 33);
		contentPane.add(lblNumEmp);

		textNumEmp = new JTextField();
		textNumEmp.setBounds(65, 132, 86, 20);
		contentPane.add(textNumEmp);
		textNumEmp.setColumns(10);

		btnMostrar = new JButton("Mostrar");
		btnMostrar.setBounds(62, 193, 100, 23);
		btnMostrar.addActionListener(this);
		contentPane.add(btnMostrar);

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(222, 86, 2, 158);
		contentPane.add(separator);


		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNombre.setBounds(250, 97, 86, 14);
		contentPane.add(lblNombre);

		JLabel lblPuesto = new JLabel("Puesto:");
		lblPuesto.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPuesto.setBounds(250, 133, 86, 14);
		contentPane.add(lblPuesto);

		JLabel lblSalario = new JLabel("Salario:");
		lblSalario.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSalario.setBounds(250, 171, 86, 14);
		contentPane.add(lblSalario);

		JLabel lblComision = new JLabel("Comisión:");
		lblComision.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblComision.setBounds(250, 213, 86, 14);
		contentPane.add(lblComision);
		
		textNombre = new JTextPane();
		textNombre.setEditable(false);
		textNombre.setBounds(346, 96, 184, 20);
		contentPane.add(textNombre);

		textPuesto = new JTextPane();
		textPuesto.setEditable(false);
		textPuesto.setBounds(346, 130, 184, 20);
		contentPane.add(textPuesto);

		textSueldo = new JTextPane();
		textSueldo.setEditable(false);
		textSueldo.setBounds(346, 171, 184, 20);
		contentPane.add(textSueldo);

		textComision = new JTextPane();
		textComision.setEditable(false);
		textComision.setBounds(346, 213, 184, 20);
		contentPane.add(textComision);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnMostrar) {
			controlador.mostrarDatos(textNumEmp.getText());
		}
	}
	
	public void mostrarDatos(String nombre, String puesto, String sueldo, String comision) {
		textNombre.setText(nombre);
		textPuesto.setText(puesto);
		textSueldo.setText(sueldo);
		textComision.setText(comision);
	}
	
	public void mostrarMensaje(String mensaje) {
		textNombre.setText("");
		textPuesto.setText("");
		textSueldo.setText("");
		textComision.setText("");
		JOptionPane.showMessageDialog(this, mensaje);
	}
}
