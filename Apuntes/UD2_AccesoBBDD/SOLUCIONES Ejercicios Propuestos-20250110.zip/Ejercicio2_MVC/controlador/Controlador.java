package controlador;

import modelo.Empleado;
import modelo.EmpleadoDAO;
import vista.VentanaDatosEmpleado;

public class Controlador {
	private VentanaDatosEmpleado vista;
	private EmpleadoDAO modelo;
	
	public Controlador() {
		this.vista = new VentanaDatosEmpleado(this);
		this.modelo = new EmpleadoDAO();
	}

	public VentanaDatosEmpleado getVista() {
		return vista;
	}

	public EmpleadoDAO getModelo() {
		return modelo;
	}
	
	public void iniciar() {
		this.vista.setVisible(true);
	}
	
	public void mostrarDatos(String numEmpleado) {
		Empleado empleado = modelo.obtenerEmpleado(Integer.parseInt(numEmpleado));
		if (empleado == null) {
			vista.mostrarMensaje("ERROR: PROBLEMA AL MOSTRAR EMPLEADO");
		} else {
			vista.mostrarDatos(empleado.getNombre(), empleado.getPuesto(), 
					Double.toString(empleado.getSueldo()), Double.toString(empleado.getComision()));
		}
	}
}
