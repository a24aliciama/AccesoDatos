package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpleadoDAO {
	private Connection conexion;
	
	public Empleado obtenerEmpleado(int numEmpleado) {
		try {
			// Definimos la consulta
			String sql = "SELECT nomemp, puesto, sal, comision FROM emp WHERE numemp=?";
			// Realizamos la conexión
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			PreparedStatement sentencia = conexion.prepareStatement(sql);
			sentencia.setInt(1, numEmpleado);
			ResultSet resultado = sentencia.executeQuery();
			resultado.next();
			return new Empleado(resultado.getString("nomemp"), resultado.getString("puesto"),
					resultado.getDouble("sal"), resultado.getDouble("comision"));
		} catch (SQLException e) {
			return null;
		}
	}
}
