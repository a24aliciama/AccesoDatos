package modelo;

public class Empleado {
	private String nombre;
	private String puesto;
	private double sueldo;
	private double comision;
	
	public Empleado(String nombre, String puesto, double sueldo, double comision) {
		this.nombre = nombre;
		this.puesto = puesto;
		this.sueldo = sueldo;
		this.comision = comision;
	}

	public String getNombre() {
		return nombre;
	}

	public String getPuesto() {
		return puesto;
	}

	public double getSueldo() {
		return sueldo;
	}

	public double getComision() {
		return comision;
	}
}
