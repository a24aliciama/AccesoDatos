package transacciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransaccionFactura {
	public static void main(String[] args) {
		try {
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/facturas", "uadmin", "abc123.");
			try {
				// Definimos las sentencias
				String sqlInsertarFactura = "INSERT INTO factura(dni_cliente) VALUES (?)";
				String sqlInsertarLineaFactura = "INSERT INTO linea_factura VALUES (?,?,?,?)";
				// Cargamos las sentencias
				PreparedStatement sInsertarFactura = conexion
						.prepareStatement(sqlInsertarFactura, PreparedStatement.RETURN_GENERATED_KEYS);
				PreparedStatement sInsertarLineaFactura = conexion.prepareStatement(sqlInsertarLineaFactura);
				// Iniciamos la transacción
				conexion.setAutoCommit(false);
				// Creamos una factura para el cliente con dni '11111111A'
				sInsertarFactura.setString(1, "11111111A");
				sInsertarFactura.executeUpdate();
				// Obtenemos el número de factura generado
				ResultSet resultado = sInsertarFactura.getGeneratedKeys();
				resultado.next();
				int numFactura = resultado.getInt(1);
				// Insertamos las lineas de factura para esa factura
				sInsertarLineaFactura.setInt(1, numFactura); // Nº factura
				sInsertarLineaFactura.setInt(2, 1); // Nº línea factura
				sInsertarLineaFactura.setString(3, "TUERCAS"); // Concepto
				sInsertarLineaFactura.setInt(4, 25); // Cantidad
				sInsertarLineaFactura.executeUpdate();
				
				sInsertarLineaFactura.setInt(1, numFactura); // Nº factura
				sInsertarLineaFactura.setInt(2, 2); // Nº línea factura
				sInsertarLineaFactura.setString(3, "TORNILLOS"); // Concepto
				sInsertarLineaFactura.setInt(4, 60); // Cantidad
				sInsertarLineaFactura.executeUpdate();
				
				conexion.commit();
				System.out.println("SE HACE COMMIT.");
			} catch (SQLException e) {
				e.printStackTrace();
				try {
					// Si hubo algún problema hacemos ROLLBACK
					conexion.rollback();
					System.out.println("SE HACE ROLLBACK.");
				} catch (SQLException er) {
					System.out.println("PROBLEMA HACIENDO ROLLBACK.");
					er.printStackTrace();
				}
			}
		} catch (SQLException e) {
			System.out.println("ERROR DE CONEXIÓN.");
			e.printStackTrace();
		}
	}
}
