package modificaciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class BorradoEmpleados {

	public static void main(String[] args) {
		// Obtenemos el número del empleado a borrar
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el número del empleado a borrar:");
		int numEmpleado = sc.nextInt();
		try {
			// Creamos la conexión
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			// Creamos la sentencia preparada
			String sql = "DELETE FROM emp WHERE numemp=?";
			PreparedStatement sentencia = conexion.prepareStatement(sql);
			sentencia.setInt(1, numEmpleado);
			// Ejecutamos la sentencia
			int filasBorradas = sentencia.executeUpdate();
			if (filasBorradas == 1) {
				System.out.println("SE HA BORRADO EL EMPLEADO CON ÉXITO.");
			} else {
				System.out.println("***PROBLEMA AL BORRAR EMPLEADO.");
			}
			// Cerramos la conexión
			conexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
