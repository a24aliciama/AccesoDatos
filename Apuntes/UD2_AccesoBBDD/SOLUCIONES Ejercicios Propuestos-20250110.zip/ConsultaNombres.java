package consultas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class ConsultaNombres {

	public static void main(String[] args) {
		// Pedimos la letra
		Scanner sc = new Scanner(System.in);
		String letra;
		do {
			System.out.println("Introduce una letra:");
			letra = sc.next().toUpperCase();
		} while (!letra.matches("[A-Z]"));
		// Creamos la conexion
		try {
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			String sql = "SELECT nomemp FROM emp WHERE nomemp LIKE ?";
			PreparedStatement sentencia = conexion.prepareStatement(sql);
			sentencia.setString(1, letra + "%");
			ResultSet resultado = sentencia.executeQuery();
			while (resultado.next()) {
				System.out.println(resultado.getString("nomemp"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
