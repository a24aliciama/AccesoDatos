package modelo;

public class Modelo {
	public int sumar(int numero1, int numero2) {
		return numero1 + numero2;
	}
}
