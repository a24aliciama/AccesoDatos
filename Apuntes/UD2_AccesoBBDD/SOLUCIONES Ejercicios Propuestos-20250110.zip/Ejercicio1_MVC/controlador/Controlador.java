package controlador;

import modelo.Modelo;
import vista.VentanaSuma;

public class Controlador {
	private VentanaSuma vista;
	private Modelo modelo;
	
	public Controlador() {
		vista = new VentanaSuma(this);
		modelo = new Modelo();
	}
	
	public void iniciar() {
		vista.setVisible(true);
	}
	
	public void sumar(String numero1, String numero2) {
		int resultado = modelo.sumar(Integer.parseInt(numero1),
				Integer.parseInt(numero2));
		vista.mostrarResultado(Integer.toString(resultado));
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
