package vista;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;


public class VentanaSuma extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textNumero1;
	private JTextField textNumero2;
	private JTextField textResultado;
	private JButton btnSumar;
	private Controlador controlador;

	public VentanaSuma(Controlador controlador) {
		this.controlador = controlador;
		
		setTitle("App suma");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 575, 273);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("SUMA DE NÚMEROS");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(196, 21, 300, 25);
		contentPane.add(lblNewLabel);

		JLabel lblNumero1 = new JLabel("Primer número:");
		lblNumero1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNumero1.setBounds(28, 74, 105, 15);
		contentPane.add(lblNumero1);

		JLabel lblNumero2 = new JLabel("Segundo número:");
		lblNumero2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNumero2.setBounds(28, 124, 150, 15);
		contentPane.add(lblNumero2);

		textNumero1 = new JTextField();
		textNumero1.setBounds(143, 72, 86, 20);
		contentPane.add(textNumero1);
		textNumero1.setColumns(10);

		textNumero2 = new JTextField();
		textNumero2.setColumns(10);
		textNumero2.setBounds(143, 122, 86, 20);
		contentPane.add(textNumero2);

		btnSumar= new JButton("SUMAR");
		btnSumar.addActionListener(this);
		btnSumar.setBounds(92, 182, 89, 23);
		contentPane.add(btnSumar);

		JLabel lblResultado = new JLabel("Resultado:");
		lblResultado.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblResultado.setBounds(385, 75, 105, 15);
		contentPane.add(lblResultado);

		textResultado = new JTextField();
		textResultado.setColumns(10);
		textResultado.setBounds(385, 101, 86, 20);
		contentPane.add(textResultado);

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(294, 74, 23, 125);
		contentPane.add(separator);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnSumar) {
			controlador.sumar(textNumero1.getText(),
					textNumero2.getText());
		}
	}
	
	public void mostrarResultado(String resultado) {
		textResultado.setText(resultado);
	}
}
