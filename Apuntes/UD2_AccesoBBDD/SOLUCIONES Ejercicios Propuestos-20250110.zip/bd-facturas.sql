DROP DATABASE IF EXISTS facturas;
CREATE DATABASE facturas;

USE facturas;

CREATE TABLE cliente(
	dni CHAR(9),
    nombre VARCHAR(250) NOT NULL,
    apellidos VARCHAR(250) NOT NULL,
    PRIMARY KEY (dni)
);

CREATE TABLE factura(
	num_factura INT AUTO_INCREMENT,
    dni_cliente CHAR(9) NOT NULL,
    PRIMARY KEY (num_factura),
    CONSTRAINT fk_cliente_factura FOREIGN KEY (dni_cliente) REFERENCES cliente(dni)
);

CREATE TABLE linea_factura(
	num_factura INT,
    linea_factura INT,
    concepto VARCHAR(250) NOT NULL,
    cantidad SMALLINT NOT NULL,
    PRIMARY KEY (num_factura, linea_factura),
    CONSTRAINT fk_linea_factura FOREIGN KEY (num_factura) REFERENCES factura(num_factura)
);

INSERT INTO cliente VALUES ('11111111A', 'David', 'Pérez López');
INSERT INTO cliente VALUES ('22222222B', 'Alicia', 'Castro Suárez');

