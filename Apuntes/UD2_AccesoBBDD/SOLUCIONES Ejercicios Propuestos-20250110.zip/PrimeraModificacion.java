package modificaciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PrimeraModificacion {
	public static void main(String[] args) {
		try {
			String consulta = "UPDATE emp SET nomemp = 'JORGE'"
					+ "WHERE numemp=7499";
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			Statement sentencia = conexion.createStatement();
			int filasAfectadas = sentencia.executeUpdate(consulta);
			System.out.println("Se modificaron " + filasAfectadas + " filas.");
			conexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
