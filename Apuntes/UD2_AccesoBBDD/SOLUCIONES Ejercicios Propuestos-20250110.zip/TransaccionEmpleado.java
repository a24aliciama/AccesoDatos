package transacciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Types;

public class TransaccionEmpleado {
	public static void main(String[] args) {
		try {
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			try {
				String sql = "INSERT INTO emp VALUES (?,?,?,?,?,?,?)";
				PreparedStatement sentencia = conexion.prepareStatement(sql);
				// Iniciamos la transacción
				conexion.setAutoCommit(false);
				int[] numemp = {7935, 7936, 7937};
				String[] nombres = {"PEDRO", "LUCÍA", "DANIEL"};
				for (int i = 0; i < 3; i++) {
					sentencia.setInt(1, numemp[i]);
					sentencia.setString(2, nombres[i]);
					sentencia.setString(3, "CONTABLE");
					sentencia.setDate(4, new Date(System.currentTimeMillis()));
					sentencia.setDouble(5, 1000);
					sentencia.setDouble(6, 300);
					//sentencia.setNull(6, Types.DOUBLE);
					sentencia.setInt(7, 1);
					sentencia.executeUpdate();
				}
				// Insertamos los tres empleados a la vez
				conexion.commit();
				System.out.println("SE HACE COMMIT.");
				conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
				try {
					// Si hubo algún problema hacemos ROLLBACK
					// No se inserta a ningun empleado
					conexion.rollback();
					System.out.println("SE HACE ROLLBACK.");
				} catch (SQLException er) {
					System.out.println("PROBLEMA HACIENDO ROLLBACK.");
					er.printStackTrace();
				}
			}
		} catch (SQLException e) {
			System.out.println("ERROR DE CONEXIÓN.");
			e.printStackTrace();
		}
	}
}
