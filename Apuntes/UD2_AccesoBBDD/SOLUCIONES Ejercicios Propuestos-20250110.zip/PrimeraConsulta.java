package consultas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PrimeraConsulta {
	public static void main(String[] args) {
		try {
			String consulta = "SELECT * FROM emp";
			Connection conexion = DriverManager
					.getConnection("jdbc:mysql://localhost/empleados", "uadmin", "abc123.");
			Statement sentencia = conexion.createStatement();
			ResultSet resultados = sentencia.executeQuery(consulta);
			while (resultados.next()) {
				int numeroEmpleado = resultados.getInt("numemp");
				String nombreEmpleado = resultados.getString("nomemp");
				System.out.println("El empleado con numero " + numeroEmpleado
						+ " se llama " + nombreEmpleado);
			}
			conexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
