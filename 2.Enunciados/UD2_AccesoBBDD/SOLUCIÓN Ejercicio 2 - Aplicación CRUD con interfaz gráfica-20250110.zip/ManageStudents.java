package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ManageStudents {
	private Connection connection;

	public void openConnection() throws SQLException {
		connection = DriverManager.getConnection("jdbc:mysql://localhost/school", "uadmin", "abc123.");
	}

	public void closeConnection() throws SQLException {
		connection.close();
	}

	public boolean addStudent(Student student) {
		try {
			String sql = "INSERT INTO student VALUES (?,?,?,?)";
			openConnection();
			PreparedStatement sentence = connection.prepareStatement(sql);
			sentence.setString(1, student.getId());
			sentence.setString(2, student.getName());
			sentence.setString(3, student.getSurname());
			sentence.setInt(4, student.getAge());
			int rows = sentence.executeUpdate();
			closeConnection();
			return rows > 0;
		} catch (SQLException e) {
			return false;
		}
	}

	public Student getStudent(String id) {
		try {
			String sql = "SELECT * FROM student WHERE id LIKE ?";
			openConnection();
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, id);
			ResultSet result = query.executeQuery();
			Student student = new Student();
			while (result.next()) {
				student.setId(result.getString("id"));
				student.setName(result.getString("name"));
				student.setSurname(result.getString("surname"));
				student.setAge(result.getInt("age"));
			}
			return student;
		} catch (SQLException e) {
			return null;
		}
	}

	public boolean deleteStudent(String id) {
		try {
			String sql = "DELETE FROM student WHERE id=?";
			openConnection();
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, id);
			int deletedRow = query.executeUpdate();
			closeConnection();
			return deletedRow == 1;
		} catch (SQLException e) {
			return false;
		}
	}

	public boolean modifyStudent(Student student) {
		try {
			String sql = "UPDATE student SET name=?, surname=?, age=?" + " WHERE id=?";
			openConnection();
			PreparedStatement sentence = connection.prepareStatement(sql);
			sentence.setString(1, student.getName());
			sentence.setString(2, student.getSurname());
			sentence.setInt(3, student.getAge());
			sentence.setString(4, student.getId());
			int rowsUpdated = sentence.executeUpdate();
			closeConnection();
			return rowsUpdated == 1;
		} catch (SQLException e) {
			return false;
		}
	}

	public ArrayList<Student> getStudentsList() {
		try {
			String sql = "SELECT * FROM student";
			openConnection();
			Statement query = connection.createStatement();
			ResultSet result = query.executeQuery(sql);
			ArrayList<Student> students = new ArrayList<Student>();
			while (result.next()) {
				Student student = new Student();
				student.setId(result.getString("id"));
				student.setName(result.getString("name"));
				student.setSurname(result.getString("surname"));
				student.setAge(result.getInt("age"));
				students.add(student);
			}
			return students;
		} catch (SQLException e) {
			return null;
		}
	}
}
