package app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import ejemplo.Depto;
import ejemplo.HibernateUtil;

public class AñadirDepartamento {

	public static void main(String[] args) {
		SessionFactory sessionFactory =
				HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		System.out.println("Insert new DEPTO...");
		Depto depto = new Depto();
		depto.setNumdep(10);
		depto.setNomdep("I+D");
		depto.setLocalidad("LUGO");
		
		session.save(depto);
		
		tx.commit();
		System.out.println("DEPTO INSERTED!");
		
		session.close();
	}

}
