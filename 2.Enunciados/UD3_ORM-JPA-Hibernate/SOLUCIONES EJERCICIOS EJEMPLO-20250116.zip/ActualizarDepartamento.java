package app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import ejemplo.Depto;
import ejemplo.Emp;
import ejemplo.HibernateUtil;

public class ActualizarDepartamento {

	public static void main(String[] args) {
		SessionFactory sessionFactory =
				HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		// Actualizamos el departamento 10
		Depto depto = session.get(Depto.class, 10);
		depto.setEmp(session.get(Emp.class, 9999));
		session.update(depto);
		// Borramos el departamento 4
		session.delete(session.get(Depto.class, 4));
		
		tx.commit();
		session.close();
	}

}
