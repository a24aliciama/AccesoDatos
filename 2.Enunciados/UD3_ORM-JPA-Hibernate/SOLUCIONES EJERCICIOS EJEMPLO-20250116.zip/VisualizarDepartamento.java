package app;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import ejemplo.Depto;
import ejemplo.Emp;
import ejemplo.HibernateUtil;

public class VisualizarDepartamento {

	public static void main(String[] args) {
		SessionFactory sessionFactory =
				HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		
		// Recuperamos el departamento 3
		Depto depto = session.get(Depto.class, 3);
		// Recuperamos los empleados del departamento
		Set<Emp> emps = depto.getEmps();
		// Mostramos la información
		System.out.println("*** EMPLEADOS DEL DEPARTAMENTO 3 ***");
		for (Emp emp: emps) {
			System.out.println(emp.getNumemp() 
					+ "   " + emp.getNomemp());
		}
		
		session.close();
	}
}
