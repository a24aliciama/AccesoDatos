package app;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import ejemplo.Emp;
import ejemplo.HibernateUtil;

public class SentenciasHQL {
	private static Session sesion;
	
	private static void iniciarSesion() {
		sesion = HibernateUtil.getSessionFactory().openSession();
	}
	
	private static void cerrarSesion() {
		sesion.close();
	}
	
	private static void mostrarComerciales() {
		// Creamos la consulta
		String hql = "FROM Emp WHERE puesto LIKE 'COMERCIAL'";
		Query consulta = sesion.createQuery(hql);
		// Ejecutamos la consulta
		List<Emp> comerciales = consulta.getResultList();
		System.out.println("NUMERO   NOMBRE   PUESTO");
		for (Emp comercial: comerciales) {
			System.out.println(comercial.getNumemp() +
					"   " + comercial.getNomemp() + "   "
					+ comercial.getPuesto());
		}
	}
	
	private static void mostrarMayorSueldo1() {
		// Creamos la consulta
		String hql = "FROM Emp ORDER BY sal DESC";
		Query consulta = sesion.createQuery(hql);
		// Ejecutamos la consulta
		Emp emp = (Emp) consulta.setMaxResults(1).getSingleResult();
		
		System.out.println("NUMERO   NOMBRE   SUELDO");
		System.out.println(emp.getNumemp() + "   " + emp.getNomemp() +
				"   " + emp.getSal());
	}
	
	private static void mostrarMayorSueldo2() {
		// Creamos la consulta
		String hql = "FROM Emp WHERE sal >= ALL(SELECT sal FROM Emp)";
		Query consulta = sesion.createQuery(hql);
		// Ejecutamos la consulta
		Emp emp = (Emp) consulta.getSingleResult();
		
		System.out.println("NUMERO   NOMBRE   SUELDO");
		System.out.println(emp.getNumemp() + "   " + emp.getNomemp() +
				"   " + emp.getSal());
	}
	
	private static void modificarSueldoManager1(BigDecimal nuevoSal) {
		// Recuperamos a todos los MANAGER
		String hql = "FROM Emp WHERE puesto LIKE 'MANAGER'";
		Query query = sesion.createQuery(hql);
		List<Emp> managers = query.getResultList();
		// Modificamos el sueldo de los MANAGER
		Transaction transaccion = sesion.beginTransaction();
		for (Emp manager: managers) {
			manager.setSal(nuevoSal);
			sesion.saveOrUpdate(manager);
		}
		transaccion.commit();
	}
	
	private static void modificarSueldoManager2(BigDecimal nuevoSal) {
		String hql = "UPDATE Emp SET sal = :numero WHERE puesto LIKE 'MANAGER'";
		Query query = sesion.createQuery(hql);
		Transaction transaccion = sesion.beginTransaction();
		int filas = query.setParameter("numero", nuevoSal).executeUpdate();
		transaccion.commit();
		System.out.println("SE HAN ACTUALIZADO " + filas + " MANAGERS");
	}
	
	private static void borrarEmpleados(int numDep) {
		String hqlQuitarJefe = "UPDATE Depto SET numJefe = NULL WHERE numDep = :numeroDep";
		String hqlBorrarEmp = "DELETE FROM Emp WHERE numDep = :numeroDep";
		Query queryJefe = sesion.createQuery(hqlQuitarJefe);
		Query queryBorrado = sesion.createQuery(hqlBorrarEmp);
		
		Transaction transaccion = sesion.beginTransaction();
		// Ponemos el jefe a NULL
		queryJefe.setParameter("numeroDep", numDep).executeUpdate();
		// Borramos los empleados del departamento
		queryBorrado.setParameter("numeroDep", numDep).executeUpdate();
		transaccion.commit();
	}
	
	public static void main(String[] args) {
		iniciarSesion();
		//mostrarComerciales();
		//mostrarMayorSueldo2();
		//modificarSueldoManager2(new BigDecimal(6000));
		//borrarEmpleados(10);
		cerrarSesion();
	}
}
