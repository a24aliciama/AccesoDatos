package app;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import ejemplo.Depto;
import ejemplo.Emp;
import ejemplo.HibernateUtil;

public class AñadirEmpleado {

	public static void main(String[] args) {
		SessionFactory sessionFactory =
				HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		System.out.println("Insert new EMP...");
		// Seleccionamos el departamento
		Depto depto = session.get(Depto.class, 10);
		// Creamos el empleado
		Emp emp = new Emp(9999, "ANTONIO", "INVESTIGADOR",
				new Date(), new BigDecimal(3500));
		// Indicamos el departamento
		emp.setDepto(depto);
		// Almacenamos el empleado
		session.save(emp);
		
		tx.commit();
		System.out.println("EMP INSERTED!");
		session.close();
	}
}
